// Update config here
export const BACKEND_URL = ''; // http://localhost:3001
